    <div class="wpb_revslider_element wpb_content_element"><link href="https://fonts.googleapis.com/css?family=Open+Sans:400" rel="stylesheet" property="stylesheet" type="text/css" media="all">
<div id="rev_slider_2_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-source="gallery" style="margin:0px auto;background:#E9E9E9;padding:0px;margin-top:0px;margin-bottom:0px;">
<!-- START REVOLUTION SLIDER 5.4.6.4 auto mode -->
    <div id="rev_slider_2_1" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.4.6.4">
<ul>    <!-- SLIDE  -->
    <li data-index="rs-5" data-transition="slideleft" data-slotamount="7" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-thumb="https://www.diptourltd.com/wp-content/uploads/2016/05/Why-travelling-to-Barcelona-is-so-easy-featured-1900x700_c-100x50.jpg"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
        <!-- MAIN IMAGE -->
        <img src="https://www.diptourltd.com/wp-content/uploads/2016/05/Why-travelling-to-Barcelona-is-so-easy-featured-1900x700_c.jpg"  alt="" title="Why-travelling-to-Barcelona-is-so-easy-featured-1900x700_c"  width="1900" height="700" data-bgposition="left top" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
        <!-- LAYERS -->

        <!-- LAYER NR. 1 -->
        <div class="tp-caption restourant_big   tp-resizeme" 
             id="slide-5-layer-2" 
             data-x="center" data-hoffset="-2" 
             data-y="187" 
                        data-width="['auto']"
            data-height="['auto']"
 
            data-type="text" 
            data-responsive_offset="on" 

            data-frames='[{"from":"y:bottom;","speed":300,"to":"o:1;","delay":800,"ease":"Power3.easeInOut"},{"delay":7600,"speed":300,"to":"auto:auto;","ease":"nothing"}]'
            data-textAlign="['left','left','left','left']"
            data-paddingtop="[0,0,0,0]"
            data-paddingright="[0,0,0,0]"
            data-paddingbottom="[0,0,0,0]"
            data-paddingleft="[0,0,0,0]"

            style="z-index: 5; white-space: nowrap; font-size: 60px; line-height: 90px; font-weight: 400; color: rgba(255,255,255,1);font-family:Open Sans;">Book your tours today </div>

        <!-- LAYER NR. 2 -->
        <div class="tp-caption text_white2   tp-resizeme" 
             id="slide-5-layer-3" 
             data-x="center" data-hoffset="9" 
             data-y="280" 
                        data-width="['auto']"
            data-height="['auto']"
 
            data-type="text" 
            data-responsive_offset="on" 

            data-frames='[{"from":"y:50px;opacity:0;","speed":300,"to":"o:1;","delay":1100,"ease":"Power3.easeInOut"},{"delay":7300,"speed":300,"to":"auto:auto;","ease":"nothing"}]'
            data-textAlign="['center','center','center','center']"
            data-paddingtop="[0,0,0,0]"
            data-paddingright="[0,0,0,0]"
            data-paddingbottom="[0,0,0,0]"
            data-paddingleft="[0,0,0,0]"

            style="z-index: 6; white-space: nowrap; font-size: 15px; line-height: 22px; font-weight: 400; color: rgba(255,255,255,1);font-family:Open Sans;">Package tours and activities </div>
    </li>
    <!-- SLIDE  -->
    <li data-index="rs-6" data-transition="slideleft" data-slotamount="7" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-thumb="https://www.diptourltd.com/wp-content/uploads/2016/05/travel-100x50.jpg"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
        <!-- MAIN IMAGE -->
        <img src="https://www.diptourltd.com/wp-content/uploads/2016/05/travel.jpg"  alt="" title="travel"  width="4288" height="2082" data-bgposition="left top" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
        <!-- LAYERS -->

        <!-- LAYER NR. 3 -->
        <div class="tp-caption restourant_big   tp-resizeme" 
             id="slide-6-layer-2" 
             data-x="center" data-hoffset="-2" 
             data-y="187" 
                        data-width="['auto']"
            data-height="['auto']"
 
            data-type="text" 
            data-responsive_offset="on" 

            data-frames='[{"from":"y:bottom;","speed":300,"to":"o:1;","delay":800,"ease":"Power3.easeInOut"},{"delay":7600,"speed":300,"to":"auto:auto;","ease":"nothing"}]'
            data-textAlign="['left','left','left','left']"
            data-paddingtop="[0,0,0,0]"
            data-paddingright="[0,0,0,0]"
            data-paddingbottom="[0,0,0,0]"
            data-paddingleft="[0,0,0,0]"

            style="z-index: 7; white-space: nowrap; font-size: 60px; line-height: 90px; font-weight: 400; color: rgba(255,255,255,1);font-family:Open Sans;">Flight Ticket </div>

        <!-- LAYER NR. 4 -->
        <div class="tp-caption text_white2   tp-resizeme" 
             id="slide-6-layer-3" 
             data-x="center" data-hoffset="9" 
             data-y="280" 
                        data-width="['auto']"
            data-height="['auto']"
 
            data-type="text" 
            data-responsive_offset="on" 

            data-frames='[{"from":"y:50px;opacity:0;","speed":300,"to":"o:1;","delay":1100,"ease":"Power3.easeInOut"},{"delay":7300,"speed":300,"to":"auto:auto;","ease":"nothing"}]'
            data-textAlign="['center','center','center','center']"
            data-paddingtop="[0,0,0,0]"
            data-paddingright="[0,0,0,0]"
            data-paddingbottom="[0,0,0,0]"
            data-paddingleft="[0,0,0,0]"

            style="z-index: 8; white-space: nowrap; font-size: 15px; line-height: 22px; font-weight: 400; color: rgba(255,255,255,1);font-family:Open Sans;">Book  your local and international flight with us  </div>
    </li>
    <!-- SLIDE  -->
    <li data-index="rs-7" data-transition="slideleft" data-slotamount="7" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-thumb="https://www.diptourltd.com/wp-content/uploads/2016/05/Lobby-100x50.jpg"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
        <!-- MAIN IMAGE -->
        <img src="https://www.diptourltd.com/wp-content/uploads/2016/05/Lobby.jpg"  alt="" title="Lobby"  width="1920" height="1200" data-bgposition="left top" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
        <!-- LAYERS -->
    </li>
    <!-- SLIDE  -->
    <li data-index="rs-8" data-transition="flyin" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="default"  data-thumb="https://www.diptourltd.com/wp-content/uploads/2016/05/travel-world-memories--100x50.png"  data-rotate="0"  data-saveperformance="off"  data-ssop="true"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
        <!-- MAIN IMAGE -->
        <img src="https://www.diptourltd.com/wp-content/uploads/2016/05/travel-world-memories-.png"  alt="" title="travel-world-memories-"  width="4244" height="2043" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
        <!-- LAYERS -->
    </li>
</ul>
<script>var htmlDiv = document.getElementById("rs-plugin-settings-inline-css"); var htmlDivCss="";
                        if(htmlDiv) {
                            htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
                        }else{
                            var htmlDiv = document.createElement("div");
                            htmlDiv.innerHTML = "<style>" + htmlDivCss + "</style>";
                            document.getElementsByTagName("head")[0].appendChild(htmlDiv.childNodes[0]);
                        }
                    </script>
<div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div> </div>
<script>var htmlDiv = document.getElementById("rs-plugin-settings-inline-css"); var htmlDivCss="";
                if(htmlDiv) {
                    htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
                }else{
                    var htmlDiv = document.createElement("div");
                    htmlDiv.innerHTML = "<style>" + htmlDivCss + "</style>";
                    document.getElementsByTagName("head")[0].appendChild(htmlDiv.childNodes[0]);
                }
            </script>
        <script type="text/javascript">
setREVStartSize({c: jQuery('#rev_slider_2_1'), gridwidth: [960], gridheight: [400], sliderLayout: 'auto'});
            
var revapi2,
    tpj=jQuery;
tpj.noConflict();           
tpj(document).ready(function() {
    if(tpj("#rev_slider_2_1").revolution == undefined){
        revslider_showDoubleJqueryError("#rev_slider_2_1");
    }else{
        revapi2 = tpj("#rev_slider_2_1").show().revolution({
            sliderType:"standard",
            jsFileLocation:"//www.diptourltd.com/wp-content/plugins/revslider/public/assets/js/",
            sliderLayout:"auto",
            dottedOverlay:"none",
            delay:9000,
            navigation: {
                keyboardNavigation:"off",
                keyboard_direction: "horizontal",
                mouseScrollNavigation:"off",
                            mouseScrollReverse:"default",
                onHoverStop:"on",
                touch:{
                    touchenabled:"on",
                    touchOnDesktop:"off",
                    swipe_threshold: 75,
                    swipe_min_touches: 1,
                    swipe_direction: "horizontal",
                    drag_block_vertical: false
                }
                ,
                arrows: {
                    style:"legenda-navigation",
                    enable:true,
                    hide_onmobile:false,
                    hide_onleave:false,
                    tmp:'<div class="tp-arr-allwrapper"></div>',
                    left: {
                        h_align:"left",
                        v_align:"center",
                        h_offset:20,
                        v_offset:0
                    },
                    right: {
                        h_align:"right",
                        v_align:"center",
                        h_offset:20,
                        v_offset:0
                    }
                }
                ,
                bullets: {
                    enable:true,
                    hide_onmobile:false,
                    style:"legenda-navigation",
                    hide_onleave:false,
                    direction:"horizontal",
                    h_align:"center",
                    v_align:"bottom",
                    h_offset:0,
                    v_offset:20,
                    space:5,
                    tmp:'<span class="tp-bullet-title"></span>'
                }
            },
            visibilityLevels:[1240,1024,778,480],
            gridwidth:960,
            gridheight:400,
            lazyType:"none",
            shadow:0,
            spinner:"spinner0",
            stopLoop:"off",
            stopAfterLoops:-1,
            stopAtSlide:-1,
            shuffle:"off",
            autoHeight:"off",
            disableProgressBar:"on",
            hideThumbsOnMobile:"off",
            hideSliderAtLimit:0,
            hideCaptionAtLimit:0,
            hideAllCaptionAtLilmit:0,
            debugMode:false,
            fallbacks: {
                simplifyAll:"off",
                nextSlideOnWindowFocus:"off",
                disableFocusListener:false,
            }
        });
    }
    
}); /*ready*/
</script>
        <script>
                    var htmlDivCss = unescape(".legenda-navigation.tparrows%20%7B%0A%09cursor%3Apointer%3B%0A%09background-color%3A%20rgba%28255%2C%20255%2C%20255%2C%200.5%29%3B%0A%09width%3A%2065px%3B%0A%20%20%20%20height%3A%2090px%3B%0A%09position%3Aabsolute%3B%0A%09display%3Ablock%3B%0A%09z-index%3A100%3B%0A%7D%0A%0A.legenda-navigation.tparrows%3Abefore%20%7B%0A%09display%3Ablock%3B%0A%09text-align%3A%20center%3B%0A%20%20%09transition%3A%20background%200.3s%2C%20color%200.3s%3B%0A%20%20%09font-family%3A%20%22arrows%22%3B%0A%20%20%20%20font-size%3A%2060px%3B%0A%20%20%20%20opacity%3A%201%3B%0A%20%20%20%20line-height%3A%2090px%3B%0A%20%20%20%20display%3A%20block%3B%0A%20%20%20%20text-indent%3A%200%3B%0A%20%20%20%20color%3A%20%23b8b8b8%3B%0A%7D%0A.legenda-navigation.tparrows.tp-leftarrow%3Abefore%20%7B%0A%09content%3A%20%22%5Ce602%22%3B%0A%7D%0A.legenda-navigation.tparrows.tp-rightarrow%3Abefore%20%7B%0A%09content%3A%20%22%5Ce603%22%3B%0A%7D%0A%0A.legenda-navigation.tparrows%3Ahover%3Abefore%20%7B%0A%20%20%20color%3A%23aaa%3B%0A%20%20%20background%3A%23fff%3B%0A%20%20%20background%3Argba%28255%2C255%2C255%2C0.7%29%3B%0A%20%7D%0A.legenda-navigation%20.tp-arr-iwrapper%20%7B%0A%7D%0A.legenda-navigation%20.tp-arr-imgholder%20%7B%0A%20%20background-size%3Acover%3B%0A%20%20position%3Aabsolute%3B%0A%20%20top%3A0px%3Bleft%3A0px%3B%0A%20%20width%3A100%25%3Bheight%3A100%25%3B%0A%7D%0A.legenda-navigation%20.tp-arr-titleholder%20%7B%0A%7D%0A.legenda-navigation%20.tp-arr-subtitleholder%20%7B%0A%7D%0A.legenda-navigation.tp-bullets%20%7B%0A%7D%0A.legenda-navigation.tp-bullets%3Abefore%20%7B%0A%09content%3A%22%20%22%3B%0A%09position%3Aabsolute%3B%0A%09width%3A100%25%3B%0A%09height%3A100%25%3B%0A%09background%3Atransparent%3B%0A%09padding%3A10px%3B%0A%09margin-left%3A-10px%3Bmargin-top%3A-10px%3B%0A%09box-sizing%3Acontent-box%3B%0A%7D%0A.legenda-navigation%20.tp-bullet%20%7B%0A%09width%3A10px%3B%0A%09height%3A10px%3B%0A%09position%3Aabsolute%3B%0A%09background%3A%23e5e5e5%3B%0A%09border-radius%3A50%25%3B%0A%09cursor%3A%20pointer%3B%0A%09box-sizing%3Acontent-box%3B%0A%7D%0A.legenda-navigation%20.tp-bullet%3Ahover%2C%0A.legenda-navigation%20.tp-bullet.selected%20%7B%0A%09background%3A%23fff%3B%0A%7D%0A");
                    var htmlDiv = document.getElementById('rs-plugin-settings-inline-css');
                    if(htmlDiv) {
                        htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
                    }
                    else{
                        var htmlDiv = document.createElement('div');
                        htmlDiv.innerHTML = '<style>' + htmlDivCss + '</style>';
                        document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[0]);
                    }
                  </script>
                </div><!-- END REVOLUTION SLIDER --></div>

<div class="container">
    <div class="page-content sidebar-position-right responsive-sidebar-bottom">
        <div class="row-fluid">
                        
            <div class="content span8">
                                    
                    <div class="vc_row wpb_row vc_row-fluid vc_custom_1469737654486 vc_row-has-fill"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner">
                        <div class="wpb_wrapper" style="padding-top: 25px;">
    <div class="wpb_text_column wpb_content_element " >
        <div class="wpb_wrapper">
            <?php echo $services;?>
        </div>
    </div>
</div></div></div></div>
<div class="hatom-extra" style="display:none;visibility:hidden;"> was last modified: <span class="updated"> March 23rd, 2019</span> </div>
                    <div class="post-navigation">
                                            </div>
                    
                    
                
            </div>

                      <!--      <div class="span4 sidebar sidebar-right">
                        
    <div class="sidebar-widget">
        <h4 class="widget-title">Search</h4>
        
<form method="get" id="searchform" class="hide-input" action="https://www.diptourltd.com/">
    <input type="text" name="s" placeholder="Search..." />
    <input type="hidden" name="post_type" value="post" />
    <input type="submit" value="Go" class="button" />
    <div class="clear"></div>
</form> </div>

                    </div> ---->
                    </div><!-- end row-fluid -->

    </div>
</div><!-- end container -->