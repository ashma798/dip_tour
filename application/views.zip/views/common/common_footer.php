        
        
    

        <footer class="mainfooter" role="contentinfo" style="margin-top: 0px;">
            <div class="footer-middle">
                <div class="container" >
                    <div class="row">
                        <div class="col-md-5 col-sm-6">
                            <!--Column1-->
                            <div class="footer-pad">
                               <img class="" src="<?php echo base_url();?>images/l2.png">

                            <?php echo $footer_info;?>
                            <ul class="list-unstyled">
                                <li><a href="#"></a></li>
                                <li>Address: Suite 7, Block 1, Bar Beach Towers, Bishop Oluwole &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp; Street Victoria Island, Lagos (LandMark: Eko Atlantic)</li>
                                <li><?php  echo $contact_info[0]['phone_no_1']; ?><br/><?php  echo $contact_info[0]['phone_no_2']; ?></li>
                                <li><a href="#">Email: <?php  echo $contact_info[0]['phone_no_3']; ?></a></li>

                            </ul>
                            </div>
                        </div>
                        <div class="col-md-2 col-sm-6">
                            <!--Column1-->
                            <div class="footer-pad">
                                <h6 ><u style="color:white; ">COMPANY INFO</u></h6>
                                <ul class="list-unstyled" style="margin-top: 25px; margin-right: 20px;">
                                    <li><i class="fa fa-caret-right" style="margin-right: 10px;"></i><a href="<?php echo base_url();?>About">About us</a></li>
                                <li><i class="fa fa-caret-right" style="margin-right: 10px;"></i><a href="<?php echo base_url();?>ServicesProvided">Services</a></li>

                                <li><i class="fa fa-caret-right" style="margin-right: 10px;"></i><a href="<?php echo base_url();?>OurPrivacyPolicy">Privacy Policy</a></li>
                                <li><i class="fa fa-caret-right" style="margin-right: 10px;"></i><a href="<?php echo base_url();?>Network">Our Network</a></li>
                                <li><i class="fa fa-caret-right" style="margin-right: 10px;"></i><a href="https://www.diptourltd.com/contact-us">Contact</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-2 col-sm-6">
                            <!--Column1-->

                            <h6 ><u style="color:white; ">POPULAR LINKS</u></h6>
                            <ul class="list-unstyled" style="margin-top: 30px; margin-left: 0">
                                <li><i class="fa fa-caret-right" style="margin-right: 10px;"></i><a href="<?php echo base_url(); ?>Blog">Blog</a></li>
                                <li><i class="fa fa-caret-right" style="margin-right: 10px;"></i><a href="#">FAQ</a></li>
                                <li><i class="fa fa-caret-right" style="margin-right: 10px;"></i><a href="#">Terms & Conditons</a></li>

                                <li>
                                    <a href="#"></a>
                                </li>
                            </ul>

                        </div>
                        <div class="col-md-3">
                            <h6 ><u style="color:white; padding-left: 100px;">NEWSLETTER</u></h6>
                            <div class="new">
                                <div class="row">

                                    <div class="content">
                                        <p>You can get latest update from us by subscribing to
                                            our newsletter.</p>  <div class="input-group">

                                            <input type="email" class="form-control" placeholder="Name/Telephone">
                                            <span class="input-group-btn">
                                                <button class="btn" type="submit">Subscribe</button>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                            </div> <div class="social" style="margin-top: 20px;">
                                <h6 style="padding-left: 70px;"><u style="color:white;" >GET CONNECTED</u></h6>
                                <a href="https://www.facebook.com/diptourltd" class="fa fa-facebook"></a>
                                <a href="https://www.twitter.com/diptourltd" class="fa fa-twitter"></a>
                                <a href="https://www.youtube.com/user/diptourltd" class="fa fa-youtube"></a>
                                <a href="https://www.linkedin.com/company/dip-tour-ltd" class="fa fa-linkedin"></a>
                                <a href="#" class="fa fa-google-plus"></a> 
                                <a href="https://www.instagram.com/diptourltd" class="fa fa-instagram"></a>  
                            </div>
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-md-12 copy">
                            <p class="text-center">&copy; Copyright 2019 - DIPTOUR  All rights reserved.</p>
                        </div>
                    </div>


                </div>
            </div>
        </footer>




    </body>
</html>