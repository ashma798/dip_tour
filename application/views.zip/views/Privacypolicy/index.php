<div class="container">
    <div class="page-content sidebar-position-right responsive-sidebar-bottom">
        <div class="row-fluid">
                        
            <div class="content span8">
                                    
                    <div class="vc_row wpb_row vc_row-fluid vc_custom_1469738106382 vc_row-has-fill"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner"><div class="wpb_wrapper">
    <div class="wpb_text_column wpb_content_element " >
        <div class="wpb_wrapper" style="padding-top: 25px;">
            <?php echo $privacy_policy?>
        </div>
    </div>
</div></div></div></div>
<div class="hatom-extra" style="display:none;visibility:hidden;"> was last modified: <span class="updated"> March 23rd, 2019</span> </div>
                    <div class="post-navigation">
                                            </div>
                    
                    
                
            </div>
<!---
                            <div class="span4 sidebar sidebar-right">
                        
    <div class="sidebar-widget">
        <h4 class="widget-title">Search</h4>
        
<form method="get" id="searchform" class="hide-input" action="https://www.diptourltd.com/">
    <input type="text" name="s" placeholder="Search..." />
    <input type="hidden" name="post_type" value="post" />
    <input type="submit" value="Go" class="button" />
    <div class="clear"></div>
</form> </div>

                    </div> --->
                    </div><!-- end row-fluid -->

    </div>
</div><!-- end container -->