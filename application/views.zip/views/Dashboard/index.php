
        <!-- Start page content wrapper -->
        <div class="page-content-wrapper animated fadeInRight">
            <div class="page-content">
             
                <div class="row wrapper border-bottom page-heading">
                    <div class="col-lg-12">
                        <h2>Dashboard <small>Control panel</small></h2>
                        <ol class="breadcrumb">
                            <li> <a href="index.html">Home</a> </li>
                            <li class="active"><a href="dash1.html"> <strong>Dashboard</strong> </a></li>
                        </ol>
                    </div>
                </div>
                <div class="wrapper-content ">

                    <!-- Start Widgets -->

                    <div class="row">
                        <!-- begin col-3 -->
                        <div class="col-md-3 col-sm-6">
                           <div class="wrapper" style="background-color: #D3D3D3; margin-right:20px;
  color: white;
  display: flex;
  flex-flow: row nowrap;
  min-height: 100%;
   border-box;border: 1px solid rgba(0,0,0,.125);border-radius: .25rem;margin-bottom:30px ;box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2); margin-top: 30px;">
  <div class="icon"  style="align-self: center;
  background-color: blue;
  color:blue;
 max-height: 100%;
  flex: 1 1 auto;
  font-size: 22px;
 padding-top: 50px; padding-bottom: 50px; padding-left: 30px;">
    <i class="fas fa-plane" style="font-size:30px;color:white;text-shadow:2px 2px 4px #000000;"></i>
  </div>
  <div class="content" style="line-height: normal;  padding-left: 20px;padding-right: 20px;">
    <h5 style="color:black;">FLIGHT BOOKING </h5>
    <p  style="color:black;">0</p>
    <p style="color:blue;">B2C Report</p>
    
  </div>
</div>
                           
                        </div>
                        <!-- end col-3 -->
                        <!-- begin col-3 -->
                        <div class="col-md-3 col-sm-6 mtop15 mright10">
                           <div class="wrapper" style="background-color: #D3D3D3; margin-right:20px;
  color: white;
  display: flex;
  flex-flow: row nowrap;
  min-height: 100%;
 border-box;border: 1px solid rgba(0,0,0,.125);border-radius: .25rem;margin-bottom:30px ;box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2); margin-top: 30px;">
  <div class="icon"  style="align-self: center;
  background-color: green;
  color:blue;
 max-height: 100%;
  flex: 1 1 auto;
  font-size: 22px;
 padding-top: 50px; padding-bottom: 50px; padding-left: 30px;">
    <i class="fas fa-bed" style="font-size:30px;color:white;text-shadow:2px 2px 4px #000000;"></i>
  </div>
  <div class="content" style="line-height: normal;  padding-left: 20px;padding-right: 20px;">
    <h5 style="color:black;">HOTEL BOOKING </h5>
    <p  style="color:black;">1</p>
    <p style="color:blue;">B2C Report</p>
    
  </div>
</div>
                            
                        </div>
                        <!-- end col-3 -->
                        <!-- begin col-3 -->
                        <div class="col-md-3 col-sm-6 mtop15">
                           <div class="wrapper" style="background-color: #D3D3D3; margin-right:20px;
  color: white;
  display: flex;
  flex-flow: row nowrap;
  min-height: 100%;
   border-box;border: 1px solid rgba(0,0,0,.125);border-radius: .25rem;margin-bottom:30px ;box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2); margin-top: 30px;">
  <div class="icon"  style="align-self: center;
  background-color: green;
  color:blue;
 max-height: 100%;
  flex: 1 1 auto;
  font-size: 22px;
 padding-top: 50px; padding-bottom: 50px; padding-left: 30px;">
    <i class="fas fa-bed" style="font-size:30px;color:white;text-shadow:2px 2px 4px #000000;"></i>
  </div>
  <div class="content" style="line-height: normal;  padding-left: 20px;padding-right: 20px;">
    <h5 style="color:black;">VILLA BOOKING </h5>
    <p  style="color:black;">0</p>
    <p style="color:blue;">B2C Report</p>
    
  </div>
</div>
                          
                        </div>
                        <!-- end col-3 -->
                        <!-- begin col-3 -->
                        <div class="col-md-3 col-sm-6 mtop15">
                           <div class="wrapper" style="background-color: #D3D3D3; margin-right:20px;
  color: white;
  display: flex;
  flex-flow: row nowrap;
  min-height: 100%;
  border-box;border: 1px solid rgba(0,0,0,.125);border-radius: .25rem;margin-bottom:30px ;box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2); margin-top: 30px;">
  <div class="icon"  style="align-self: center;
  background-color: red;
  color:blue;
 max-height: 100%;
  flex: 1 1 auto;
  font-size: 22px;
 padding-top: 50px; padding-bottom: 50px; padding-left: 30px;">
    <i class="fas fa-bus" style="font-size:30px;color:white;text-shadow:2px 2px 4px #000000;"></i>
  </div>
  <div class="content" style="line-height: normal;  padding-left: 20px;padding-right: 20px;">
    <h5 style="color:black;">BUS BOOKING </h5>
    <p  style="color:black;">0</p>
    <p style="color:blue;">B2C Report</p>
    
  </div>
</div>
                           
                        </div>
                        <!-- end col-3 -->

                        <!-- begin col-3 -->
                       
                       
                                              
                    </div>


                   
                   

                   
                    </div>
                   
                    <!-- End Widgets -->

                </div>
                <!-- /wrapper-content -->

                <!-- start footer -->
                
