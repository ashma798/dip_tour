<style type="text/css">
  *{
    box-sizing: border-box;
  }
  .navbar-custom {
   
   
    margin-top:0px;
    
}

   .navbar-ch{
    margin-top:0px;
    border:2px solid black;
    border-radius: 3%;
   background-color: white;
   margin-left: 50px;
   margin-right: 50px;
   }


/* equal card height */

.newsletter-form {
    color: #fff;
    display: inline-block;
    padding: 25px 0;
    position: relative;
    vertical-align: middle;
    width: 100%;
    z-index: 1
}

.newsletter {
    position: relative;
   
}

.newsletter .container {
    left: 0;
    position: absolute;
    right: 0;
    margin-bottom:150px;
    margin-top: 0px;
}

.newsletter .info {
    font-size: 18px;
    line-height: 1.5;
    margin: 0
}

.newsletter .info strong {
    font-weight: 600
}

.newsletter .theme-btn {
    background-color: green;
    float: right
}

.newsletter .theme-btn:hover {
    background-color: #333
}
.theme-btn {
    border: medium none;
    border-radius: 3px;
    color: #fff;
    font-size: 13px;
    font-weight: 600;
    height: 50px;
    line-height: 30px;
    padding: 10px 25px;
    text-transform: uppercase;
    width: 150px;
    margin-top: 25px;
}
[role=button] {
    cursor: pointer;
}
.newsletter-form input {
   
    background-position: left bottom;
    background-repeat: no-repeat;
    background-color: rgba(0, 0, 0, 0);
    border: medium none;
    margin-top: 0;
    padding: 15px 5px;
    position: relative;
    width: 90%;
    float: right;
    margin-right: 20px;
    box-shadow: none
}


.slideshow-container {
  position: relative;
  background:black;
}

/* Slides */








/* Add a background color to the active dot/circle */


/* Add an italic font style to all quotes */
q {font-style: italic;}

/* Add a blue color to the author */
.author {color: cornflowerblue;}

/*FOOTER*/

footer {
  background: black;
  
  color: white;
 
}

footer a {
  color: #fff;
  font-size: 14px;
  transition-duration: 0.2s;
}

footer a:hover {
  color: #4CBB17;
  text-decoration: none;
}

.copy {
  font-size: 12px;
  padding: 10px;
  border-top: 1px solid #FFFFFF;
}

.footer-middle {
  padding-top: 2em;
  color: white;
}


/*SOCİAL İCONS*/



/* footer social icons */





.top {
font-family: 'Comfortaa', cursive;
}

#myCarousel {
  padding: 0 10px 30px 10px;
  margin-top: 30px;
}

.carousel-item blockquote {
    border-left: none; 
    margin: 0;
 } 

.title{
 font-family: 'Comfortaa', cursive;

 a{
  color:darkorange;
  transition: all .2s;

a:hover {
  text-decoration: none;
  color: orange;
} } }


/* Small devices (tablets, 768px and up) */
@media (min-width: 768px) { 
    #quote-carousel 
    {
      margin-bottom: 0;
      padding: 0 40px 30px 40px;
    }
    
}

.off_div {
    top: 0;
    background: #452f91;
    color: #fff;
    padding: 4px 10px;
    font-size: 12px;
    font-weight: 500;
}
 .off_div {
    position: absolute;
    right: 0;
}
.off_div:after {
    height: 0;
    border-left: 15px solid transparent;
    border-right: 15px solid transparent;
    border-top: 18px solid #452f91;
    position: absolute;
    left: -24px;
    top: 6px;
    transform: rotate(90deg);
}
.off_div:after {
    content: "";
}

.col_box {
    border: 1px solid #025ecb;
    box-shadow: 1px 2px 3px rgba(2,2,2,.37);
    padding: auto;
    color: white;
    font-weight: 500;
    font-size: 14px;
    margin: 0 0 35px;
    width: 150px;
    background-color: green;
     text-align: center;
}

.col_box img {
    max-width: 55px;
    margin: 8px auto;
    max-height: 50px;
    min-height: 50px;
    object-fit: contain;
}
  .topnav {
  overflow: hidden;
 
}





.topnav-right {
  float: right;
  color:black;
  padding-right: 50px;
}

.new{
padding:  0;
background: black;
}

.new .content {
max-width:850px;
margin: 0 auto;
text-align: center;
position: relative;
z-index: 2; }

.new .content .form-control {
height: 50px;
border-color: #ffffff;
border-radius:0;
padding-left: 40px;
}
.new .content.form-control:focus {
box-shadow: none;
border: 2px solid #243c4f;
}
.new .content .btn {
min-height: 50px; 
border-radius:0;
background: #9ACD32;
color: #fff;
font-weight:600;
}
 
.social .fa {
  padding: 7px;
  font-size: 18px;
  width: 33px;
  text-align: center;
  text-decoration: none;
  margin: 5px 2px;
}

.social .fa:hover {
    opacity: 0.7;
}

.social .fa-facebook {
  background: black;
  color: white;
  border:2px solid white;
}
.social .fa-twitter {
  background: black;
  color: white;
  border:2px solid white;
}
.social .fa-youtube {
  background: black;
  color: white;
  border:2px solid white;
}
.social .fa-google-plus {
  background: black;
  color: white;
  border:2px solid white;
}
.social .fa-linkedin {
  background: black;
  color: white;
  border:2px solid white;
}
.social .fa-instagram {
  background: black;
  color: white;
  border:2px solid white;
}


</style>
        
           
  <section id="" class="at-widgets acme-contact ">  <style type="text/css">
        @import url('https://fonts.googleapis.com/css?family=Yantramanav:100,300');

/* ------------- */
/* GLOBAL STYLES */
/* ------------- */

* {
  box-sizing: border-box;
}

body {
  background:white;
  color: #485e74;
  line-height: 1.6;
  font-family: 'Yantramanav', sans-serif;
  padding: 1em;
}

.container {
  max-width: 1170px;
  margin-left: auto;
  margin-right: auto;
  padding: 1em;
}

ul {
  list-style: none;
  padding: 0;
}

.brand {
  text-align: center;
    font-weight: 300;
    text-transform: uppercase;
    letter-spacing: 0.1em;
}

.brand span {
  color: #ffffff;
}

.wrapper {
  box-shadow: 0 0 20px 0 rgba(57, 82, 163, 0.7);
}

.wrapper > * {
  padding: 1em;
}

/* ------------------- */
/* COMPANY INFORMATION */
/* ------------------- */

.company-info {
  background: #77a339;
  border-top-left-radius: 4px;
  border-top-right-radius: 4px;
}

.company-info h3,
.company-info ul {
  text-align: center;
  margin: 0 0 1rem 0;
}

/* ------- */
/* CONTACT */
/* ------- */

.contact {
  background: #c5dea2;
  border-bottom-left-radius: 4px;
  border-bottom-right-radius: 4px;
}

/* ---- */
/* FORM */
/* ---- */

.contact form {
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-gap: 20px;
}

.contact form label {
  display: block;
}

.contact form p {
  margin: 0;
}

.contact form .full {
  grid-column: 1 / 3;
}

.contact form button,
.contact form input,
.contact form textarea {
  width: 100%;
  padding: 1em;
  border: solid 1px #627EDC;
  border-radius: 4px;
}

.contact form textarea {
  resize: none;
}

.contact form button {
  background: #627EDC;
  border: 0;
  color: #e4e4e4;
  text-transform: uppercase;
  font-size: 14px;
  font-weight: bold;
}

.contact form button:hover,
.contact form button:focus {
  background: #3952a3;
  color: #ffffff;
  outline: 0;
  transition: background-color 2s ease-out;
}

/* ------------- */
/* MEDIA QUERIES */
/* ------------- */
input[type=checkbox] + label {
  display: block;
  margin: 0.2em;
  cursor: pointer;
  padding: 0.2em;
}

input[type=checkbox] {
  display: none;
}

input[type=checkbox] + label:before {
  content: "\2714";
  border: 0.1em solid #000;
  border-radius: 0.2em;
  display: inline-block;
  width: 1em;
  height: 1em;
  padding-left: 0.2em;
  padding-bottom: 0.3em;
  margin-right: 0.2em;
  vertical-align: bottom;
  color: transparent;
  transition: .2s;
}

 

input[type=checkbox]:checked + label:before {
  background-color: MediumSeaGreen;
  border-color: MediumSeaGreen;
  color: #fff;
}


@media only screen and (min-width: 400px) {
  .wrapper {
    display: grid;
    grid-template-columns: 1fr 2fr;
  }

  .wrapper > * {
    padding: 2em;
  }

  .company-info {
    border-radius: 4px 0 0 4px;
  }

  .contact {
    border-radius: 0 4px 4px 0;
  }

  .company-info h3,
  .company-info ul,
  .brand {
    text-align: left;
  }
}
@media screen and (max-width: 990px) and (min-width: 320px) {
						.widthauto {
							width:100% !important;
						}
						.mrtop {
							margin-top:695px !important;
						}
						
					}
    </style>
    <section class="container p-t-1">
    <div class="row" style="margin-top:20px; margin-bottom: 50px;border-radius: 5px solid ">
        <div class="col-lg-12">
          <h3 class="" style=" text-align: center;color:green; font-size: 32px;line-height: 44px;font-weight: 400;font-style: normal;
    font-family: 'Playfair Display', serif;
    text-transform: capitalize;">Send Us a message to discuss your Visa needs</h3>
            <h5 style="text-align: center; color:green; font-weight: bold;">CONTACT US</h5>
<p style="text-align: center;">Get in touch with us.</p>
<p class="lead" style="text-align: center;">Looking for something or have destination suggestions?<br />Tell us about it!</p><div class="row"></div>
<hr class="small" style="border:1px solid green;">
<h3 style="font-weight: bold; text-align: center;">FILL THE FORM</h3>
 <hr class="small" style="border:1px solid green;">
         
<div class="widthauto" style="width: 1200px; margin: 0px auto;">
     <div class="container">

    <h1 class="brand"><span>Diptour</span></h1>

    <div class="wrapper">

        <!-- COMPANY INFORMATION -->
        <div class="">
            <img class="" src="<?php echo base_url(); ?>images/logo.png" style="margin-bottom: 20px;">
           

            <ul>
                <li><i class="fa fa-road"></i> Suite 7, Block 1, Bar Beach Towers, Bishop Oluwole                 
                Street Victoria Island, Lagos (LandMark: Eko Atlantic)</li>
                <li><i class="fa fa-phone"></i> +234 8122820856</li>
                <li><i class="fa fa-phone"></i> +234 8170592433</li>
                <li><i class="fa fa-envelope"></i> info@diptourltd.com</li>
              </ul>        
      </div>


         <div class="container"> <link   rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.6/css/all.css"> <style type="text/css">form > div {
  display: flex;
  flex-wrap: wrap;
}

form > div > p {
  min-width: 33.33%;
  padding: 10px;
}

form p { color: black; }

/* ------------------- */
/* Form Styles
/* ----------------- */

form > div { margin-bottom: 1em; }

button,
input,
optgroup,
select,
keygen::-webkit-keygen-select,
select[_moz-type="-mozilla-keygen"],
textarea {
  color: inherit;
  font: inherit;
  margin: 0;
  margin-top: 0.5em;
}

label {
  display: block;
  margin: 0.75em 0;
  font-weight: bold;
}

/*input[type="radio"] + label,
input[type="checkbox"] + label { 
  margin: 0;
  font-weight: 400; 
}*/

button,
input[type=button],
input[type=reset],
input[type=submit],
{
  -webkit-appearance: button;
  cursor: pointer;
}

button[disabled],
input[disabled] {
  cursor: default;
}

input {
  line-height: normal;
}

textarea { line-height: 1.25em; }

select {
  border: 1px solid #ccc;
  background-color: #fff;
}

/*input[type=checkbox],
input[type=radio] {
  box-sizing: border-box;
  padding: 0;
  display: block;
  margin-right: 0.25em;
  margin-top: 2px;
  float: left;
  clear: both;
}*/

input[type=search] {
    -webkit-appearance: textfield;
    -moz-box-sizing: content-box;
    -webkit-box-sizing: content-box;
  box-sizing: content-box;
}

input[type=search]::-webkit-search-cancel-button,
input[type=search]::-webkit-search-decoration {
  -webkit-appearance: none;
}

input[type=text],
input[type=password],
input[type=email],
input[type=url],
input[type=date],
input[type=month],
input[type=time],
input[type=datetime],
input[type=datetime-local],
input[type=week],
input[type=number],
input[type=search],
input[type=tel],
input[type=color],
select[_moz-type="-mozilla-keygen"],
keygen::-webkit-keygen-select,
select,
textarea {
  border: 1px solid #ccc;
  box-shadow: inset 0 1px 3px #ddd;
  border-radius: 2px;
  vertical-align: middle;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
  box-sizing: border-box;
  max-width: 100%;
  padding: 0.5em 0.6em;
  margin-bottom: 0.5em;
}

input[type=color] {
  padding: 0;
}

input:not([type]) {
  display: inline-block;
  border: 1px solid #ccc;
  box-shadow: inset 0 1px 3px #ddd;
  border-radius: 2px;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
  box-sizing: border-box;
  padding: 0.5em 0.6em;
}

input[type=color] {
  padding: 0.2em 0.5em;
}

input[type="date"] {
    position: relative;
}

/* create a new arrow, because we are going to mess up the native one
see "List of symbols" below if you want another, you could also try to add a font-awesome icon.. */
input[type="date"]:after {
    font-family: "Font Awesome 5 Free";
    font-weight: 0; 
    content: "\f073";
    color: #555;
    padding: 0 5px;
}

/* change color of symbol on hover */
input[type="date"]:hover:after {
    color: #bf1400;
}

/* make the native arrow invisible and stretch it over the whole field so you can click anywhere in the input field to trigger the native datepicker*/
input[type="date"]::-webkit-calendar-picker-indicator {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    width: auto;
    height: auto;
    color: transparent;
    background: transparent;
}

/* adjust increase/decrease button */
input[type="date"]::-webkit-inner-spin-button {
    z-index: 1;
}

 /* adjust clear button */
 input[type="date"]::-webkit-clear-button {
     z-index: 1;
 }
input[type=file]:focus,
input[type=radio]:focus,
/*input[type=checkbox]:focus*/ {
  outline: 1px auto #129FEA;
}

input[readonly],
select[readonly],
textarea[readonly] {
  background-color: #eee;
  color: #777;
  border-color: #ccc;
}

input:focus:invalid,
textarea:focus:invalid,
select:focus:invalid {
  color: #b94a48;
  border-color: #e9322d;
  }

input[type=file]:focus:invalid:focus,
input[type=radio]:focus:invalid:focus,
/*input[type=checkbox]:focus:invalid:focus*/ {
  outline-color: #e9322d;
}


/* Style your form buttons. Follow your heart */

input[type="submit"],
input[type="reset"],
input[type="button"],
button {
  display: inline-block;
  padding: 8px 12px;
  color: white;
  background-color: green;
  border: 0;
  cursor: pointer;
  transition: all 300ms ease;
}

input[type="submit"]:hover,
input[type="reset"]:hover,
input[type="button"]:hover,
button:hover {
  background-color: royalblue;
}</style>
<h2><?php echo $this->session->flashdata('item'); ?></h2> 
  <h6 style="color:black; font-weight: bold;">Personal details (as it appears on passport)</h6>
  
<form method="post" action="<?php echo base_url('/visa/add'); ?>" enctype="multipart/form-data">
  <div>
  <p>
    <label>
     Full Name<span style="color:red;">*</span><br>
    <input type="text" placeholder="Full Name" name="full_name" value="" required>
    </label>
  </p>
  <p>
    <label>
      Date of birth<span style="color:red;">*</span><br>
    <input type="date" name="dob" placeholder="" required>
    </label>
  </p>
  <p>
    <label>
      No. of travelers<span style="color:red;">*</span><br>
    <input type="number" placeholder="No. of travelers" name="no_of_travellers" required>
    </label>
  </p>

   <p>
    <label>
      Address<br>
    <input type="text" placeholder="Address" name="address" required>
    </label>
  </p>
   <p>
    <label>
      Tel<span style="color:red;">*</span><br>
    <input type="number" placeholder="Tel" name="telephone" required min="1111111111">

    </label>
  </p>
  <p>
    <label>
      Email <i class="fa fa-envelope fa-sm fa-fw" aria-hidden="true"></i><br>
    <input type="email" placeholder="something@email.com" name="email" required>

    </label>
  </p>

<p>
    <label>
      Marital Status<span style="color:red;">*</span> <br>
    <input type="text" placeholder="Marital Status" name="marital_status" required>

    </label>
  </p>

   <p>
    <label>
      No. of child(s)<span style="color:red;"></span> <br>
    <input type="number" placeholder="No. of child(s)" name="no_of_child">

    </label>
  </p>

    <p>
    <label>
      Countries visited since last 5yrs<span style="color:red;">*</span> <br>
    <input type="text" placeholder="countries visited" name="countries_visited_since_last_5yrs" required>

    </label>
  </p>

   <p>
    <label>
      Are you employed<span style="color:red;">*</span> <br>
    <select name="are_you_employed" required>
      <option value="" disabled selected>Select...</option>
       <option value = "IT Professional"> IT Professional</option>
      <option value ="Businessman"> Businessman</option>
    </select>

    </label>
  </p>
    
    
    <p>
    <label>
      Profession <br>
    <input type="text" placeholder="Profession" name="profession" required>

    </label>
  </p>



    <p>
    <label>
      Range of monthly income<span style="color:red;">*</span> <br>
    
<select name="range_of_monthly_income" required>
      <option value="" disabled selected>Select...</option>
       <option value="5000-10,000"> 5000-10,000</option>
      <option value="10,000-15,000"> 10,000-15,000</option>
      <option value="15,000-25,000"> 15,000-25,000</option>
      <option value="25,000-35,000"> 25,000-35,000</option>
      <option value="35,000-60,000"> 35,000-60,000</option>
    </select>

    </label>
  </p>

  <p>
    <label>
      Business Owner<span style="color:red;">*</span> <br>
    <input type="text" placeholder="Business owner" name="busines_owner">

    </label>
  </p>

    <p>
    <label>
      Type of Business <br>
    <input type="text" placeholder="type of Business" name="type_of_business">

    </label>
  </p>

  <p>
    <label>
      Is Business Registered?<br>
    <input type="text" placeholder="Is Business Registered" name="is_business_registered">

    </label>
  </p>


  <p>
    <label>
    Estimated Monthly Inflow<br>
    <input type="text" placeholder="Estimated Monthly Inflow" name="estimated_monthly_inflow" required>
    </label>
  </p>
  
  </div>
  <div>
  <h6 style="color: black;  font-weight: bold;">Destination Details</h6>
</div>
<div>

  <p>
    <label>
      Country of Interest<span style="color:red;">*</span> <br>
    <input type="text" placeholder="country of interest" name="country_of_interest">

    </label>
  </p>


   <p>
    <label>
      Purpose of Travel<span style="color:red;">*</span> <br>
    <input type="text" placeholder= "purpose of travel" name="purpose_of_travel">

    </label>
  </p>

    <p>
    <label>
      Sponsor <br>
    <input type="text" placeholder="sponsor" name="sponsor">

    </label>
  </p>

   <p>
    <label>
      Relationsip of Sponsor to you <br>
    <input type="text" placeholder=" relationship of sponsor"  name="relationship_of_sponsor_to_you">
    </label>
  </p>

  <p>
    <label>
      Intended Date of travel<br>
    <input type="date" placeholder=""  name="intended_date_of_travel">
    </label>
  </p>

   

   <p>
    <label>
      Duration of Stay <span style="color:red;">*</span> <br>
    <input type="number" placeholder=" number of days"  name="duration_of_stay">
    </label>
  </p>

   <p>
    <label>
      No. of Person(s)Travelling with You<br>
    <input type="number" placeholder="no. of person(s)"  name="no_of_persons_travelling_with_you">
    </label>
  </p>

   <p>
    <label>
      Relationsip of Person(s)Travelling with You <br>
    <input type="text" placeholder=" relationship of person(s)" name="relationship_of_persons_travelling_with_you">
    </label>
  </p>
</div>
<div>
  <h6 style="font-weight: bold;">Additions</h6>
</div>
<div>
  <p>
    <label>
     Do you require Flight Tickets?<br>
    <input type="text" placeholder=" do you require flight tickets?" name="do_you_require_flight_tickets">
    </label>
  </p>

   <p>
    <label>
     Accomodation<br>
    <input type="text" placeholder="Accomodation"  name="accomodation">
    </label>
  </p> 

  <p>
    <label>
     Travel Insurance<br>
    <input type="text" placeholder="Travel Insurance"  name="travel_insurance">
    </label>
  </p>
  <p>
    <label>
     Message<br>
    <textarea rows="5" cols="40" name="message" placeholder="Your message. I'm afraid I still don't understand, sir. Maybe if we felt any human loss as keenly as we feel one of those close to us, human history would be far less bloody."></textarea>
    </label>
  </p> 
  </div>
  <div>
    <h6 style="color:black;font-weight: bold;"> Guarantor/Refernce Information:(Optional)If applicable for the process and intended country of destination.</h6> </div>
    <div>

      <p>
    <label>
     Name<br>
    <input type="text" placeholder="Name" name="guarantor_name">
    </label>
  </p>
  <p>
    <label>
     Address<br>
    <input type="text" placeholder="Address" name="guarantor_address">
    </label>
  </p>
  <p>
    <label>
     Relationship<br>
    <input type="text" placeholder="Travel Insurance" name="guarantor_relationship">
    </label>
  </p>
   <p>
    <label>
      Email <i class="fa fa-envelope fa-sm fa-fw" aria-hidden="true"></i><br>
    <input type="email" placeholder="something@email.com" name="guarantor_email">

    </label>
  </p>
   <p>
    <label>
      Tel<span style="color:red;">*</span><br>
    <input type="number" placeholder="Tel" name="guarantor_tel" min="1111111111">

    </label>
  </p>
  
 </div>
 <div><h5  style="font-weight: bold;color: black; ">Department</h5></div>
 <div class="form-inline">
                     <div class="form-group">
               <input type="checkbox" id="fruit1" name="ticketing" >
  <label for="fruit1">Ticketing</label></div>
  <div class="form-group">
  <input type="checkbox" id="fruit2" name="travel_deals_sales"  >
  <label for="fruit2">Travel Deals & Sales</label></div>
   <div class="form-group">
  <input type="checkbox" id="fruit3" name="visa_assistance" >
  <label for="fruit3">Visa Assistance</label></div>
   <div class="form-group">
  <input type="checkbox" id="fruit4" name="customer_support" >
  <label for="fruit4">Customer Support</label></div></div>
 <div>
 <h6><span style="color:black;font-weight: bold;">Upload file(s):</span>(Optional) If applicable for the process</h6>
  </div>
  <div>
  
  <!--<p>
    <label>
      datalist (Start typing This...)<br>
      <input list="datalist">
      <datalist id="datalist">
          <option>This is option 1</option>
          <option>This is option 2</option>
          <option>This is option 3</option>
      </datalist>
    </label>
  </p>
  
  <p>
    <label>
      output<br>
      <output>123</output>
    </label>
  </p>
  <p>
      <input type="radio" name="radio" value="Radio 1" id="rad1"><label for="rad1">Radio 1</label><br>
      <input type="radio" name="radio" value="Radio 2" id="rad2"><label for="rad2">Radio 2</label><br>
      <input type="radio" name="radio" value="Radio 3" id="rad3"><label for="rad3">Radio 3</label><br>
  </p>
  <p>
    <input type="checkbox" name="checkbox" value="Checkbox 1" id="cb1"><label for="cb1">Checkbox 1</label><br>
    <input type="checkbox" name="checkbox" value="Checkbox 2" id="cb2"><label for="cb2">Checkbox 2</label><br>
    <input type="checkbox" name="checkbox" value="Checkbox 3" id="cb3"><label for="cb3">Checkbox 3</label><br>
  </p>
  <p>
    <label>color</label>
    <input type="color">
  </p>
  <p>
    <label>
      range<br>
    <input type="range" id="rangeSlider" min="0" max="100" step="10" onchange="printValue('rangeSlider', 'rangeValue')">
    <input type="text" id="rangeValue" size="3">
    </label>
  </p>-->
  <p>
    <input type="file" name="upload_document" id="file">
  </p>
</div>
  <div class="form-inline">
    <div class="form-group">
      
        <button type="submit"> Submit </button>
     &nbsp;
     &nbsp;
     &nbsp;
     &nbsp;    
        <button type="reset"> Reset </button>
      
    </div>
  </div>
  <!--<p>
      <button>Button (button tag)</button>
  </p>-->
  </div>
  
</form>
</div>



        <!-- End .company-info -->

        <!-- CONTACT FORM -->
        <!--<div class="contact">
            <h3 style="font-weight: bold;">E-mail Us</h3>

            <form id="contact-form">

                <p>
                    <label>Name</label>
                    <input type="text" name="name" id="name" required>
                </p>

                <p>
                    <label>Company</label>
                    <input type="text" name="company" id="company">
                </p>

                <p>
                    <label>E-mail Address</label>
                    <input type="email" name="email" id="email" required>
                </p>

                <p>
                    <label>Phone Number</label>
                    <input type="text" name="phone" id="phone">
                </p>

                <p class="full">
                    <label>Message</label>
                    <textarea name="message" rows="5" id="message"></textarea>
                </p>

                   <br/>
                   <h5 style="text-align: left; margin-left: -350px; font-weight: bold;">Department</h5>
               
                 <div class="form-inline">
                     <div class="form-group">
               <input type="checkbox" id="fruit1" name="fruit-1" value="Ticketing">
  <label for="fruit1">Ticketing</label></div>
  <div class="form-group">
  <input type="checkbox" id="fruit2" name="fruit-2" value="Travel Deals & Sales" >
  <label for="fruit2">Travel Deals & Sales</label></div>
   <div class="form-group">
  <input type="checkbox" id="fruit3" name="fruit-3" value="Visa Assistance">
  <label for="fruit3">Visa Assistance</label></div>
   <div class="form-group">
  <input type="checkbox" id="fruit4" name="fruit-4" value="Customer Support">
  <label for="fruit4">Customer Support</label></div></div>

                    <button type="submit" style="background-color:green; font-size: 20px;">Submit</button>
            
                
           </form>
       </div>
           
     
 
            End #contact-form -->
        
        <!-- End .contact -->

    </div>
    <!-- End .wrapper -->
</div>
<!-- End .container -->
</div>
</div>
</div>
</section>




   
         

                         <section class="">
            <div class="newsletter" >
              <div class="container newsletter-bg-colour" style="margin-top:0px;
    background-color: #ffffff; border-style: solid; padding-bottom: 20px;padding-top: 20px;
"> <form>
  <div class="form-row">
    <div class="form-group col-md-2">
      <label for="inputEmail4">Keywords</label>
      <input type="email" class="form-control" id="inputEmail4" placeholder="Keywords">
    </div>
    <div class="form-group col-md-1">
      <label for="inputPassword4">Category</label>
      <input type="password" class="form-control" id="inputPassword4" placeholder="Category">
    </div>
  
  <div class="form-group col-md-1">
    <label for="inputAddress">Duration</label>
    <input type="text" class="form-control" id="inputAddress" placeholder="Duration">
  </div>
  <div class="form-group col-md-2">
    <label for="inputAddress2">Date</label>
    <input type="text" class="form-control" id="inputAddress2" placeholder="Date">
  </div>
 
    <div class="form-group col-md-2">
      <label for="inputCity">Min Price</label>
    <select id="inputState" class="form-control">
        <option selected>Choose...</option>
        <option>...</option>
      </select>
    </div>
    <div class="form-group col-md-2">
      <label for="inputState">Max Price</label>
      <select id="inputState" class="form-control">
        <option selected>Choose...</option>
        <option>...</option>
      </select>
    </div>
   
  
  
  <div class="form-group col-md-2 ">
     <a href="contact.html" class="theme-btn btn-2" role="button"  style="background-color: green; text-align: center;"   type="button">SEARCH</a>
  </div>
  


                

         </form></div></div></section>
  

  
</section>
<br><br><br>
<br><br><br>
