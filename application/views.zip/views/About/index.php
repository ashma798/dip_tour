  <style type="text/css">
      /*media all*/
.sidebar-widget .widget-title {
    padding: 20px 0;
    margin-bottom: 20px;
    border-top: 1px solid #ebebeb;
    border-bottom: 1px solid #ebebeb;
}
/*media all*/
.footer-top .container {
    border-top: 1px solid #dbdbdb;
    padding-top: 2px;
}
/*media all*/
.copyright.copyright-3, .copyright.copyright-2 {
    background: #343434;
    border-top: 1px solid #333536;
    color: #8b8b8b;
}
/*media all*/
.back-to-top.btt-shown {
    bottom: 50px;
}
/*media all*/
.back-to-top::before {
    content: "\e601";
    font-family: "arrows";
    font-size: 14px;
    opacity: 1;
    display: block;
    text-indent: 0px;
    line-height: 48px;
    color: #fff;
    height: 50px;
    text-align: center;
    width: 50px;
    background: rgba(0, 0, 0, 0.2);
    -webkit-transition: 0.3s all ease-in-out;
    -moz-transition: 0.3s all ease-in-out;
    -ms-transition: 0.3s all ease-in-out;
    -o-transition: 0.3s all ease-in-out;
    transition: 0.3s all ease-in-out;
}
/*media all*/
#searchModal {
    display: inline-block;
    width: 90%;
    opacity: 1;
    max-width: 410px;
    left: 50%;
    margin-left: 0px;
    -webkit-transform: translateX(-50%);
    -moz-transform: translateX(-50%);
    -ms-transform: translateX(-50%);
    -o-transform: translateX(-50%);
    transform: translateX(-50%);
    position: relative;
    background-color: #fff;
    text-align: center;
}
/*media all*/
.vc_column_container > .vc_column-inner {
    box-sizing: border-box;
    padding-left: 15px;
    padding-right: 15px;
    width: 100%;
}
/*media all*/
.vc_column-inner::after {
    clear: both;
}
 /*media all*/
.footer-top .container {
    border-top: 1px solid #dbdbdb;
    padding-top: 2px;
}
/*media all*/
.footer-top .container .double-border {
    padding: 30px 0;
}
/*media all*/
.vc_row {
    margin-left: -15px;
    margin-right: -15px;
}
/*@media all and (min-width:768px)*/
.vc_col-sm-3 {
    width: 25%;
}
/*media all*/
.vc_column_container {
    padding-left: 0px;
    padding-right: 0px;
}
/*media all*/
.vc_column_container > .vc_column-inner {
    box-sizing: border-box;
    padding-left: 15px;
    padding-right: 15px;
    width: 100%;
}
/*media all*/
.vc_col-has-fill > .vc_column-inner, .vc_row-has-fill + .vc_row-full-width + .vc_row > .vc_column_container > .vc_column-inner, .vc_row-has-fill + .vc_row > .vc_column_container > .vc_column-inner, .vc_row-has-fill > .vc_column_container > .vc_column-inner {
    padding-top: 35px;
}
/*media all*/
.vc_column_container > .vc_column-inner {
    box-sizing: border-box;
    padding-left: 15px;
    padding-right: 15px;
    width: 100%;
}


  </style>
         
<div class="container">
    <div class="page-content sidebar-position-right responsive-sidebar-bottom">
        <div class="row-fluid">
                        
            <div class="content span8">
                                    
                    <div class="vc_row wpb_row vc_row-fluid vc_custom_1469737429391 vc_row-has-fill"><div class="wpb_column vc_column_container vc_col-sm-12">
                        <div class="vc_column-inner" style="width: 900px;"><div class="wpb_wrapper">
    <div class="wpb_text_column wpb_content_element " >
        <div class="wpb_wrapper">
            <?php echo $about_us ?>;

        </div>
    </div>
</div></div></div></div>
<div class="hatom-extra" style="display:none;visibility:hidden;"> was last modified: <span class="updated"> March 23rd, 2019</span> </div>
                    <div class="post-navigation">
                                            </div>
                    
                    
                
            </div>
                    </div><!-- end row-fluid -->

    </div>
</div><!-- end container -->
    
        
        
    

        </div></div></p>
                       
                </div>
            </div>
        </div>
        
         
    
    </div> <!-- page wrapper -->
    
               
        <div id="cartModal" class="modal hide fade" tabindex="-1" role="dialog" aria-hidden="true"><div id="shopping-cart-modal">           <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h3 class="title"><span>Cart</span></h3>
            </div>
        <div class="modal-body">            <div class="shopping-cart-modal a-right" >
                <div class="cart-popup-container">
                    <div class="cart-popup">
                        <div class="widget_shopping_cart_content">
                        <p class="woocommerce-mini-cart__empty-message empty a-center">No products in the cart.</p>                     </div>
                    </div>
                </div>
            </div>

        </div></div></div>
    <!--Embed from Zendesk Chat Chat Wordpress Plugin v1.4.15-->
    <!--Start of Zopim Live Chat Script-->
    <script type="text/javascript">
    window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
    d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
      _.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute('charset','utf-8');
      $.src='//v2.zopim.com/?526pyTUQdZjopieGI2MgxBgWHEk2Oiei';z.t=+new Date;$.
      type='text/javascript';e.parentNode.insertBefore($,e)})(document,'script');
      </script><script>$zopim( function() {
})</script><!--End of Zendesk Chat Script-->    <script type="text/javascript">
        var c = document.body.className;
        c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
        document.body.className = c;
    </script>
                <script type="text/javascript">
                function revslider_showDoubleJqueryError(sliderID) {
                    var errorMessage = "Revolution Slider Error: You have some jquery.js library include that comes after the revolution files js include.";
                    errorMessage += "<br> This includes make eliminates the revolution slider libraries, and make it not work.";
                    errorMessage += "<br><br> To fix it you can:<br>&nbsp;&nbsp;&nbsp; 1. In the Slider Settings -> Troubleshooting set option:  <strong><b>Put JS Includes To Body</b></strong> option to true.";
                    errorMessage += "<br>&nbsp;&nbsp;&nbsp; 2. Find the double jquery.js include and remove it.";
                    errorMessage = "<span style='font-size:16px;color:#BC0C06;'>" + errorMessage + "</span>";
                        jQuery(sliderID).show().html(errorMessage);
                }
            </script>
            <script type='text/javascript' src='https://www.diptourltd.com/wp-content/plugins/myMail/assets/js/form.js?ver=1.3.6.1'></script>
        <script type="text/javascript">
            var wc_product_block_data = JSON.parse( decodeURIComponent ( '%7B%22min_columns%22%3A1%2C%22max_columns%22%3A6%2C%22default_columns%22%3A3%2C%22min_rows%22%3A1%2C%22max_rows%22%3A6%2C%22default_rows%22%3A1%2C%22thumbnail_size%22%3A300%2C%22placeholderImgSrc%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fwp-content%5C%2Fuploads%5C%2Fwoocommerce-placeholder-300x300.png%22%2C%22min_height%22%3A500%2C%22default_height%22%3A500%2C%22isLargeCatalog%22%3Afalse%2C%22limitTags%22%3Afalse%2C%22hasTags%22%3Afalse%2C%22productCategories%22%3A%5B%7B%22term_id%22%3A20%2C%22name%22%3A%22Bahamas%22%2C%22slug%22%3A%22bahamas%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A20%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A2%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Fbahamas%5C%2F%22%7D%2C%7B%22term_id%22%3A30%2C%22name%22%3A%22China%22%2C%22slug%22%3A%22china%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A30%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Fchina%5C%2F%22%7D%2C%7B%22term_id%22%3A36%2C%22name%22%3A%22Egypt%22%2C%22slug%22%3A%22egypt%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A36%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Fegypt%5C%2F%22%7D%2C%7B%22term_id%22%3A28%2C%22name%22%3A%22England%22%2C%22slug%22%3A%22england%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A28%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Fengland%5C%2F%22%7D%2C%7B%22term_id%22%3A32%2C%22name%22%3A%22France%22%2C%22slug%22%3A%22france%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A32%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Ffrance%5C%2F%22%7D%2C%7B%22term_id%22%3A26%2C%22name%22%3A%22Gambia%22%2C%22slug%22%3A%22gambia%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A26%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Fgambia%5C%2F%22%7D%2C%7B%22term_id%22%3A24%2C%22name%22%3A%22Ghana%22%2C%22slug%22%3A%22ghana%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A24%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Fghana%5C%2F%22%7D%2C%7B%22term_id%22%3A38%2C%22name%22%3A%22Israel%22%2C%22slug%22%3A%22israel%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A38%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Fisrael%5C%2F%22%7D%2C%7B%22term_id%22%3A27%2C%22name%22%3A%22Italy%22%2C%22slug%22%3A%22italy%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A27%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Fitaly%5C%2F%22%7D%2C%7B%22term_id%22%3A37%2C%22name%22%3A%22Jordan%22%2C%22slug%22%3A%22jordan%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A37%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Fjordan%5C%2F%22%7D%2C%7B%22term_id%22%3A23%2C%22name%22%3A%22Kenya%22%2C%22slug%22%3A%22kenya%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A23%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Fkenya%5C%2F%22%7D%2C%7B%22term_id%22%3A22%2C%22name%22%3A%22Maldives%22%2C%22slug%22%3A%22maldives%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A22%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Fmaldives%5C%2F%22%7D%2C%7B%22term_id%22%3A33%2C%22name%22%3A%22Netherlands%22%2C%22slug%22%3A%22netherlands%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A33%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Fnetherlands%5C%2F%22%7D%2C%7B%22term_id%22%3A21%2C%22name%22%3A%22Nigeria%22%2C%22slug%22%3A%22nigeria%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A21%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A1%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Fnigeria%5C%2F%22%7D%2C%7B%22term_id%22%3A39%2C%22name%22%3A%22Saudi%20Arabia%22%2C%22slug%22%3A%22saudi-arabia%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A39%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Fsaudi-arabia%5C%2F%22%7D%2C%7B%22term_id%22%3A34%2C%22name%22%3A%22South%20Africa%22%2C%22slug%22%3A%22south-africa%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A34%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Fsouth-africa%5C%2F%22%7D%2C%7B%22term_id%22%3A25%2C%22name%22%3A%22Tanzania%22%2C%22slug%22%3A%22tanzania%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A25%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Ftanzania%5C%2F%22%7D%2C%7B%22term_id%22%3A31%2C%22name%22%3A%22Thailand%22%2C%22slug%22%3A%22thailand%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A31%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Fthailand%5C%2F%22%7D%2C%7B%22term_id%22%3A35%2C%22name%22%3A%22Turkey%22%2C%22slug%22%3A%22turkey%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A35%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Fturkey%5C%2F%22%7D%2C%7B%22term_id%22%3A75%2C%22name%22%3A%22Uncategorized%22%2C%22slug%22%3A%22uncategorized%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A75%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Funcategorized%5C%2F%22%7D%2C%7B%22term_id%22%3A40%2C%22name%22%3A%22United%20Arab%20Emirate%22%2C%22slug%22%3A%22united-arab-emirate%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A40%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Funited-arab-emirate%5C%2F%22%7D%2C%7B%22term_id%22%3A29%2C%22name%22%3A%22United%20States%22%2C%22slug%22%3A%22united-states%22%2C%22term_group%22%3A0%2C%22term_taxonomy_id%22%3A29%2C%22taxonomy%22%3A%22product_cat%22%2C%22description%22%3A%22%22%2C%22parent%22%3A0%2C%22count%22%3A0%2C%22filter%22%3A%22raw%22%2C%22link%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2Fproduct-category%5C%2Funited-states%5C%2F%22%7D%5D%2C%22homeUrl%22%3A%22https%3A%5C%2F%5C%2Fwww.diptourltd.com%5C%2F%22%7D' ) );
        </script>
        <link rel='stylesheet' id='vc_google_fonts_abril_fatfaceregular-css'  href='https://fonts.googleapis.com/css?family=Abril+Fatface%3Aregular&#038;ver=5.2.4' type='text/css' media='all' />
<script type='text/javascript' src='https://www.diptourltd.com/wp-content/plugins/yith-woocommerce-wishlist/assets/js/jquery.selectBox.min.js?ver=1.2.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var yith_wcwl_l10n = {"ajax_url":"\/wp-admin\/admin-ajax.php","redirect_to_cart":"no","multi_wishlist":"","hide_add_button":"1","is_user_logged_in":"","ajax_loader_url":"https:\/\/www.diptourltd.com\/wp-content\/plugins\/yith-woocommerce-wishlist\/assets\/images\/ajax-loader.gif","remove_from_wishlist_after_add_to_cart":"yes","labels":{"cookie_disabled":"We are sorry, but this feature is available only if cookies are enabled on your browser.","added_to_cart_message":"<div class=\"woocommerce-message\">Product correctly added to cart<\/div>"},"actions":{"add_to_wishlist_action":"add_to_wishlist","remove_from_wishlist_action":"remove_from_wishlist","move_to_another_wishlist_action":"move_to_another_wishlsit","reload_wishlist_and_adding_elem_action":"reload_wishlist_and_adding_elem"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.diptourltd.com/wp-content/plugins/yith-woocommerce-wishlist/assets/js/jquery.yith-wcwl.js?ver=2.2.13'></script>
<script type='text/javascript' src='https://www.diptourltd.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.diptourltd.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=3.7.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_7978a85d5b69c2cd112ee267efde8ead","fragment_name":"wc_fragments_7978a85d5b69c2cd112ee267efde8ead","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.diptourltd.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=3.7.0'></script>
<script type='text/javascript' src='//www.diptourltd.com/wp-content/plugins/woocommerce/assets/js/prettyPhoto/jquery.prettyPhoto.min.js?ver=3.1.6'></script>
<script type='text/javascript' src='https://www.diptourltd.com/wp-includes/js/underscore.min.js?ver=1.8.3'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.diptourltd.com/wp-includes/js/wp-util.min.js?ver=5.2.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_variation_params = {"wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_no_matching_variations_text":"Sorry, no products matched your selection. Please choose a different combination.","i18n_make_a_selection_text":"Please select some product options before adding this product to your cart.","i18n_unavailable_text":"Sorry, this product is unavailable. Please choose a different combination."};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.diptourltd.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart-variation.min.js?ver=3.7.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var ethemeLocal = {"tClose":"Close (Esc)"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.diptourltd.com/wp-content/themes/legenda%20NULLED/js/plugins.min.js?ver=5.2.4'></script>
<script type='text/javascript' src='https://www.diptourltd.com/wp-content/plugins/js_composer/assets/lib/waypoints/waypoints.min.js?ver=5.7'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var myAjax = {"ajaxurl":"https:\/\/www.diptourltd.com\/wp-admin\/admin-ajax.php","noresults":"No results were found!"};
/* ]]> */
</script>
<script type='text/javascript' src='https://www.diptourltd.com/wp-content/themes/legenda%20NULLED/js/etheme.js?ver=5.2.4'></script>
<script type='text/javascript' src='https://www.diptourltd.com/wp-includes/js/wp-embed.min.js?ver=5.2.4'></script>
<script type='text/javascript' src='https://www.diptourltd.com/wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min.js?ver=5.7'></script>
    <script>
    jQuery(document).ready(function() {
      
    });
    </script>
    
